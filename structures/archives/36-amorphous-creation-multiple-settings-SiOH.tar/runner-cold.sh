echo "runner pid: $$"

FFIELDS=(
	# "SiC"
	# "CHONSi"
	# "CHONSSi"
	# "SiONH"	
	"SiOH"
	# "SiOHv2"
	# "CHONSSiCaCsKSrNaMgAlCu"
	# "CHONSSiGe"
	# "CHONSSiNaAl"
	# "CHONSSiNaFZr"
	# "CHONSSiNaP"
	# "CHONSSiNaP-tribology"
	# "CHONSSiPtNiCuCoZrYBa"
	# "CHONSSiPtZrNiCuCo"
	# "CHONSSiPtZrNiCuCoHeNeArKrXe"
	# "WATER"	
)
FOGARTY_SCRIPTS=(
	# "PART1_STEP_1_MINIMISE_NVE"
	# "PART1_STEP_2_MELT_NVT"
	# "PART1_STEP_3_HOLD_NVT"
	# "PART1_STEP_4_QUENCH_NVT"
	# "PART1_STEP_5_COLD_NVT"
	"PART2_STEP_1_MINIMISE_NPT"
	"PART2_STEP_2_MELT_NPT"
	"PART2_STEP_3_HOLD_NPT"
	"PART2_STEP_4_QUENCH_NPT"
	"PART2_STEP_5_COLD_NPT"
)

RUN_DATE=(
	"2021.07.17-1315-8ps100K-aniso-5Bpdf"
	"2021.07.16-1450-4ps100K-aniso-200Mpdf"
	"2021.07.15-1700-8ps100K-aniso-20Mpdf"
	"2021.07.16-2145-16ps100K-aniso-50Bpdf"
)

FOGARTY_SCRIPTS_COUNT=5
INPUT_FILE="SiO2-768atoms"
NVT_MINIMISED_FILE="SiO2-768atoms-NVT-8ps100K"
ELEMENTS="Si O"
SEED_VALUE=7256

for((k=0;k<4;k++)); do
	for((i=0;i<1;i++)); do
		echo "Input File: $1_${j}"
		# cp ${NVT_MINIMISED_FILE}.lmp RESULT_${FFIELDS[$i]}_${RUN_DATE}_${INPUT_FILE}_PART1_STEP5.ignore.lmp
		for ((j=4;j<${FOGARTY_SCRIPTS_COUNT};j++)); do
			echo "Running script ${j} : ${FOGARTY_SCRIPTS[${j}]}.in :"
			setsid nohup ~/bin/lmp_latest_kokkos/lmp_latest_kokkos \
			-in ${FOGARTY_SCRIPTS[$j]}.in \
			-var run_date ${RUN_DATE[$k]} \
			-var ffield ${FFIELDS[$i]} \
			-var filename ${INPUT_FILE} \
			-var general_seedValue ${SEED_VALUE} \
			-var elements "${ELEMENTS}" \
			-k on t 16 -sf kk &> RESULT_${FFIELDS[$i]}_${RUN_DATE[$k]}_${INPUT_FILE}_STEP_${j}.out
		done
	done
done
