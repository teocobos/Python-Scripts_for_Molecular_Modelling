echo "runner pid: $$"

FFIELDS=(
	# "SiC"
	# "CHONSi"
	# "CHONSSi"
	# "SiONH"	
	"SiOH"
	# "SiOHv2"
	# "CHONSSiCaCsKSrNaMgAlCu"
	# "CHONSSiGe"
	# "CHONSSiNaAl"
	# "CHONSSiNaFZr"
	# "CHONSSiNaP"
	# "CHONSSiNaP-tribology"
	# "CHONSSiPtNiCuCoZrYBa"
	# "CHONSSiPtZrNiCuCo"
	# "CHONSSiPtZrNiCuCoHeNeArKrXe"
	# "WATER"	
)
FOGARTY_SCRIPTS=(
	# "PART1_STEP_1_MINIMISE_NVE"
	# "PART1_STEP_2_MELT_NVT"
	# "PART1_STEP_3_HOLD_NVT"
	# "PART1_STEP_4_QUENCH_NVT"
	# "PART1_STEP_5_COLD_NVT"
	"PART2_STEP_1_MINIMISE_NPT"
	"PART2_STEP_2_MELT_NPT"
	"PART2_STEP_3_HOLD_NPT"
	"PART2_STEP_4_QUENCH_NPT"
	"PART2_STEP_5_ROOM_NPT"
	"PART2_STEP_6_COLD_NPT"
)

RUN_DATE="2021.07.20-0300-16ps100K-aniso-20Bpdf"
FOGARTY_SCRIPTS_COUNT=6
INPUT_FILE="SiO2-768atoms"
NVT_MINIMISED_FILE="SiO2-768atoms-NVT-8ps100K"
ELEMENTS="Si O"
SEED_VALUE=2879

for((i=0;i<1;i++)); do
	echo "Input File: $1_${j}"

	#cp ${INPUT_FILE}.lmp RESULT_${FFIELDS[$i]}_${RUN_DATE}_${INPUT_FILE}_STEP_0.ignore.lmp
	
	cp ${NVT_MINIMISED_FILE}.lmp RESULT_${FFIELDS[$i]}_${RUN_DATE}_${INPUT_FILE}_PART1_STEP5.ignore.lmp
	for ((j=0;j<${FOGARTY_SCRIPTS_COUNT};j++)); do
		echo "Running script ${j} : ${FOGARTY_SCRIPTS[${j}]}.in :"
		setsid nohup ~/bin/lmp_latest_kokkos/lmp_latest_kokkos \
		-in ${FOGARTY_SCRIPTS[$j]}.in \
		-var run_date ${RUN_DATE} \
		-var ffield ${FFIELDS[$i]} \
		-var filename ${INPUT_FILE} \
		-var general_seedValue ${SEED_VALUE} \
		-var elements "${ELEMENTS}" \
		-k on t 16 -sf kk &> RESULT_${FFIELDS[$i]}_${RUN_DATE}_${INPUT_FILE}_STEP_${j}.out
	done
done
